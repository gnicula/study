final class DefineConstants
{
	public static final int MAX_SIZE_TO_PRINT = 10;
	public static final int INVALID_VALUE = -1;
}